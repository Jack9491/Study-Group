﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    public class Student
    {

        public string KNum { get; set; }

        public string StudentName { get; set; }

        public int StudentAge { get; set; }

        public string Gender { get; set; }

        public int StudyYear { get; set; }


        public string County { get; set; }

       // public string Availability { get; set; }

        public string StudentPhoneNumber { get; set; }

        public bool IsPresent { get; set; }
        public int ParticipationScore { get; set; }


        public Student()
        {

        }

        public Student(string kNum, string Sname, int StAge, string Sgender, int Syear,  string Scounty, string SPhone, bool Present, int PScore)
        {
            this.KNum = kNum;
            this.StudentName = Sname;
            this.StudentAge = StAge;
            this.Gender = Sgender;
            this.StudyYear = Syear;
            this.County = Scounty;
            this.StudentPhoneNumber = SPhone;
            this.IsPresent = Present;
            this.ParticipationScore = PScore;

        }







    }
}

﻿namespace GroupProject
{
    partial class SessionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SessionsForm));
            btnSessionsCancel = new Button();
            btnAddSessions = new Button();
            txtIsBooked = new TextBox();
            lblStudyIsBooked = new Label();
            lblSessionAgenda = new Label();
            txtSessionAssignments = new TextBox();
            lblSessionsAssignments = new Label();
            lblGroupMembers = new Label();
            txtTopic = new TextBox();
            lblTopic = new Label();
            txtRoomNr = new TextBox();
            lblRoomNr = new Label();
            lblDateTime = new Label();
            dtpSessions = new DateTimePicker();
            txtSessionsAgenda = new TextBox();
            txtGroupMembers = new TextBox();
            lblSessionName = new Label();
            txtSessionName = new TextBox();
            SuspendLayout();
            // 
            // btnSessionsCancel
            // 
            btnSessionsCancel.Location = new Point(288, 316);
            btnSessionsCancel.Name = "btnSessionsCancel";
            btnSessionsCancel.Size = new Size(94, 37);
            btnSessionsCancel.TabIndex = 38;
            btnSessionsCancel.Text = "&Cancel";
            btnSessionsCancel.UseVisualStyleBackColor = true;
            btnSessionsCancel.Click += btnSessionsCancel_Click;
            // 
            // btnAddSessions
            // 
            btnAddSessions.Location = new Point(79, 316);
            btnAddSessions.Name = "btnAddSessions";
            btnAddSessions.Size = new Size(94, 37);
            btnAddSessions.TabIndex = 36;
            btnAddSessions.Text = "&Accept";
            btnAddSessions.UseVisualStyleBackColor = true;
            btnAddSessions.Click += btnAddSessions_Click;
            // 
            // txtIsBooked
            // 
            txtIsBooked.Location = new Point(149, 262);
            txtIsBooked.Name = "txtIsBooked";
            txtIsBooked.PlaceholderText = "True/False";
            txtIsBooked.Size = new Size(250, 27);
            txtIsBooked.TabIndex = 35;
            txtIsBooked.TextChanged += txtIsBooked_TextChanged;
            // 
            // lblStudyIsBooked
            // 
            lblStudyIsBooked.AutoSize = true;
            lblStudyIsBooked.Location = new Point(29, 264);
            lblStudyIsBooked.Name = "lblStudyIsBooked";
            lblStudyIsBooked.Size = new Size(77, 20);
            lblStudyIsBooked.TabIndex = 34;
            lblStudyIsBooked.Text = "Is Booked:";
            // 
            // lblSessionAgenda
            // 
            lblSessionAgenda.AutoSize = true;
            lblSessionAgenda.Location = new Point(29, 230);
            lblSessionAgenda.Name = "lblSessionAgenda";
            lblSessionAgenda.Size = new Size(64, 20);
            lblSessionAgenda.TabIndex = 32;
            lblSessionAgenda.Text = "Agenda:";
            // 
            // txtSessionAssignments
            // 
            txtSessionAssignments.Location = new Point(150, 194);
            txtSessionAssignments.Name = "txtSessionAssignments";
            txtSessionAssignments.PlaceholderText = "2...";
            txtSessionAssignments.Size = new Size(250, 27);
            txtSessionAssignments.TabIndex = 31;
            // 
            // lblSessionsAssignments
            // 
            lblSessionsAssignments.AutoSize = true;
            lblSessionsAssignments.Location = new Point(29, 197);
            lblSessionsAssignments.Name = "lblSessionsAssignments";
            lblSessionsAssignments.Size = new Size(95, 20);
            lblSessionsAssignments.TabIndex = 30;
            lblSessionsAssignments.Text = "Assignments:";
            // 
            // lblGroupMembers
            // 
            lblGroupMembers.AutoSize = true;
            lblGroupMembers.Location = new Point(29, 163);
            lblGroupMembers.Name = "lblGroupMembers";
            lblGroupMembers.Size = new Size(119, 20);
            lblGroupMembers.TabIndex = 28;
            lblGroupMembers.Text = "Group Members:";
            // 
            // txtTopic
            // 
            txtTopic.Location = new Point(150, 127);
            txtTopic.Name = "txtTopic";
            txtTopic.PlaceholderText = "Chapter 22 Loops...";
            txtTopic.Size = new Size(250, 27);
            txtTopic.TabIndex = 27;
            // 
            // lblTopic
            // 
            lblTopic.AutoSize = true;
            lblTopic.Location = new Point(29, 130);
            lblTopic.Name = "lblTopic";
            lblTopic.Size = new Size(48, 20);
            lblTopic.TabIndex = 26;
            lblTopic.Text = "Topic:";
            // 
            // txtRoomNr
            // 
            txtRoomNr.Location = new Point(150, 94);
            txtRoomNr.Name = "txtRoomNr";
            txtRoomNr.PlaceholderText = "16...";
            txtRoomNr.Size = new Size(250, 27);
            txtRoomNr.TabIndex = 25;
            // 
            // lblRoomNr
            // 
            lblRoomNr.AutoSize = true;
            lblRoomNr.Location = new Point(29, 96);
            lblRoomNr.Name = "lblRoomNr";
            lblRoomNr.Size = new Size(110, 20);
            lblRoomNr.TabIndex = 24;
            lblRoomNr.Text = "Room Number:";
            // 
            // lblDateTime
            // 
            lblDateTime.AutoSize = true;
            lblDateTime.Location = new Point(29, 62);
            lblDateTime.Name = "lblDateTime";
            lblDateTime.Size = new Size(110, 20);
            lblDateTime.TabIndex = 22;
            lblDateTime.Text = "Date and Time:";
            // 
            // dtpSessions
            // 
            dtpSessions.Location = new Point(150, 60);
            dtpSessions.Name = "dtpSessions";
            dtpSessions.Size = new Size(250, 27);
            dtpSessions.TabIndex = 23;
            // 
            // txtSessionsAgenda
            // 
            txtSessionsAgenda.Location = new Point(150, 228);
            txtSessionsAgenda.Name = "txtSessionsAgenda";
            txtSessionsAgenda.PlaceholderText = "Complete Chapter 22...";
            txtSessionsAgenda.Size = new Size(250, 27);
            txtSessionsAgenda.TabIndex = 33;
            // 
            // txtGroupMembers
            // 
            txtGroupMembers.Location = new Point(150, 161);
            txtGroupMembers.Margin = new Padding(2);
            txtGroupMembers.Name = "txtGroupMembers";
            txtGroupMembers.PlaceholderText = "4...";
            txtGroupMembers.Size = new Size(250, 27);
            txtGroupMembers.TabIndex = 29;
            // 
            // lblSessionName
            // 
            lblSessionName.AutoSize = true;
            lblSessionName.Location = new Point(29, 29);
            lblSessionName.Name = "lblSessionName";
            lblSessionName.Size = new Size(105, 20);
            lblSessionName.TabIndex = 20;
            lblSessionName.Text = "Session Name:";
            // 
            // txtSessionName
            // 
            txtSessionName.Location = new Point(150, 26);
            txtSessionName.Name = "txtSessionName";
            txtSessionName.PlaceholderText = "Session 1...";
            txtSessionName.Size = new Size(250, 27);
            txtSessionName.TabIndex = 21;
            // 
            // SessionsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(420, 371);
            Controls.Add(txtSessionName);
            Controls.Add(lblSessionName);
            Controls.Add(txtGroupMembers);
            Controls.Add(txtSessionsAgenda);
            Controls.Add(dtpSessions);
            Controls.Add(btnSessionsCancel);
            Controls.Add(btnAddSessions);
            Controls.Add(txtIsBooked);
            Controls.Add(lblStudyIsBooked);
            Controls.Add(lblSessionAgenda);
            Controls.Add(txtSessionAssignments);
            Controls.Add(lblSessionsAssignments);
            Controls.Add(lblGroupMembers);
            Controls.Add(txtTopic);
            Controls.Add(lblTopic);
            Controls.Add(txtRoomNr);
            Controls.Add(lblRoomNr);
            Controls.Add(lblDateTime);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "SessionsForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Study Group | Add Session";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        //private Button btnStudentCancel;
        private Button btnAddStudent;
        private ComboBox cbxCounty;
        private ComboBox cbxStudentYear;
        private TextBox txtPhoneNum;
        private Label txtPhoneNumber;
        private TextBox txtAvailability;
        private Label lblAvailability;
        private Label lblCounty;
        private TextBox txtStudentKnum;
        private Label lblSessionsAssignments;
        private Label lblGroupMembers;
        private TextBox txtTopic;
        private Label lblTopic;
        private TextBox txtRoomNr;
        private Label lblRoomNr;
        private Label lblDateTime;
        private DateTimePicker dtpSessions;
        private TextBox txtSessionsAgenda;
        private Button btnSessionsCancel;
        private Button btnAddSessions;
        private TextBox txtIsBooked;
        private Label lblStudyIsBooked;
        private Label lblSessionAgenda;
        private TextBox txtSessionAssignments;
        private TextBox txtGroupMembers;
        private Label lblSessionName;
        private TextBox txtSessionName;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
//using System.Windows.Forms.DataVisualization.Charting;

namespace GroupProject
{
    public partial class StudentChart : Form
    {
        List<Student> students = new List<Student>();
        public StudentChart(List<Student> students)
        {

            InitializeComponent();
            this.students = students;
        }

        private void StudentChart_Load(object sender, EventArgs e)
        {
            int MaleCount = students.Count(st => st.Gender == "Male");
            int FemaleCount = students.Count(st => st.Gender == "Female");

            StudentPressentChart.Series.Clear();
            StudentPressentChart.Series.Add("Gender");
            StudentPressentChart.Series["Gender"].ChartType = SeriesChartType.Pie;


            StudentPressentChart.Series["Gender"].Points.AddXY("Male", MaleCount);
            StudentPressentChart.Series["Gender"].Points.AddXY("Female", FemaleCount);


            StudentPressentChart.Titles.Add("Gender");
            StudentPressentChart.Series["Gender"].BorderWidth = 5;

            StudentPressentChart.Series["Gender"].Color = Color.Green;
            StudentPressentChart.Series["Gender"].BorderWidth = 5;
            StudentPressentChart.Series["Gender"].MarkerStyle = MarkerStyle.Diamond;
            StudentPressentChart.Series["Gender"].MarkerSize = 5;
            StudentPressentChart.Series["Gender"].MarkerColor = Color.Green;

            StudentPressentChart.Legends.Add("Gender Display");
            StudentPressentChart.Legends[0].LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Table;
            StudentPressentChart.Legends[0].Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            StudentPressentChart.Legends[0].Alignment = StringAlignment.Center;
            StudentPressentChart.Legends[0].Title = "Gender Display";
            StudentPressentChart.Legends[0].BorderColor = Color.Black;
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void btnStudentChartExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace GroupProject
{
    public partial class SessionsForm : Form
    {
        public bool AddSession { get; set; }
        public Sessions session { get; set; }

        public SessionsForm()
        {
            InitializeComponent();
        }

        private void btnAddSessions_Click(object sender, EventArgs e)
        {
            if (AddSession)
            {
                this.session = new();
            }
            this.LoadSessionData();

            this.DialogResult = DialogResult.OK;
        }

        private void DisplaySession()
        {

            txtSessionName.Text = session.SessionName;
            dtpSessions.Text = session.DateAndTime.ToString();
            txtRoomNr.Text = session.RoomNum.ToString();
            txtTopic.Text = session.Topic;
            txtGroupMembers.Text = session.GroupMembers;
            txtSessionAssignments.Text = session.AssignmentQs;
            txtSessionsAgenda.Text = session.Agenda;
            txtIsBooked.Text = session.IsBooked.ToString();

        }

        private void LoadSessionData()
        {
            session.SessionName = txtSessionName.Text;
            session.DateAndTime = DateTime.Parse(dtpSessions.Text);
            session.RoomNum = int.Parse(txtRoomNr.Text);
            session.Topic = txtTopic.Text;
            session.GroupMembers = txtGroupMembers.Text;
            session.AssignmentQs = txtSessionAssignments.Text;
            session.Agenda = txtSessionsAgenda.Text;
            session.IsBooked = bool.Parse(txtIsBooked.Text);
        }

        private void SessionForm_Load(object sender, EventArgs e)
        {
            if (AddSession)
            {
                this.Text = "Add Session";
                txtSessionName.ReadOnly = false;  // allow entry of new session name
            }
            else
            {
                this.Text = "Modify Session";
                txtSessionName.ReadOnly = true;   // can't change existing session name
                this.DisplaySession();
            }
        }

        private void btnSessionsCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtIsBooked_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

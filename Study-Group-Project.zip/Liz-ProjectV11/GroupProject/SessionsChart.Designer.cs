﻿namespace GroupProject
{
    partial class SessionsChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            SessionsRoomBookedChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            btnSessionChartExit = new Button();
            ((System.ComponentModel.ISupportInitialize)SessionsRoomBookedChart).BeginInit();
            SuspendLayout();
            // 
            // SessionsRoomBookedChart
            // 
            chartArea3.Name = "ChartArea1";
            SessionsRoomBookedChart.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            SessionsRoomBookedChart.Legends.Add(legend3);
            SessionsRoomBookedChart.Location = new Point(82, 25);
            SessionsRoomBookedChart.Margin = new Padding(4, 4, 4, 4);
            SessionsRoomBookedChart.Name = "SessionsRoomBookedChart";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            SessionsRoomBookedChart.Series.Add(series3);
            SessionsRoomBookedChart.Size = new Size(469, 469);
            SessionsRoomBookedChart.TabIndex = 0;
            SessionsRoomBookedChart.Text = "SessionsRoomBookedChart";
            // 
            // btnSessionChartExit
            // 
            btnSessionChartExit.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnSessionChartExit.ForeColor = Color.MidnightBlue;
            btnSessionChartExit.Location = new Point(235, 520);
            btnSessionChartExit.Margin = new Padding(4, 4, 4, 4);
            btnSessionChartExit.Name = "btnSessionChartExit";
            btnSessionChartExit.Size = new Size(120, 45);
            btnSessionChartExit.TabIndex = 1;
            btnSessionChartExit.Text = "&Exit";
            btnSessionChartExit.UseVisualStyleBackColor = true;
            btnSessionChartExit.Click += btnSessionChartExit_Click;
            // 
            // SessionsChart
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(623, 589);
            Controls.Add(btnSessionChartExit);
            Controls.Add(SessionsRoomBookedChart);
            Margin = new Padding(4, 4, 4, 4);
            Name = "SessionsChart";
            Text = "SessionsChart";
            Load += SessionsChart_Load;
            ((System.ComponentModel.ISupportInitialize)SessionsRoomBookedChart).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart SessionsRoomBookedChart;
        private Button btnSessionChartExit;
    }
}
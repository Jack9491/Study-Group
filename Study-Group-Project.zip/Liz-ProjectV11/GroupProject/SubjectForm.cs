﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GroupProject
{
    public partial class SubjectForm : Form
    {
        public bool AddSubject { get; set; }

        public Subject subject { get; set; }

        public SubjectForm()
        {
            InitializeComponent();
        }

        private void btnAddSubject_Click(object sender, EventArgs e)
        {
            if (AddSubject)
            {
                this.subject = new Subject();
            }
            this.LoadSubjectData();

            this.DialogResult = DialogResult.OK;
        }

        private void DisplaySubject()
        {

            txtSubjectName.Text = subject.SubjectName;
            txtSubjectDescription.Text = subject.SubjectDescription;
            txtOutcomes.Text = subject.LearningOutcome;
            cbxSubjectYear.Text = subject.YearOfStudy.ToString();
            txtPreReq.Text = subject.Prerequisites;
            txtSubjectProjects.Text = subject.Projects;
            txtSubjectMaterials.Text = subject.StudyMaterial;
            txtSubjectRoles.Text = subject.RolesAndResponsibilities;

        }

        private void LoadSubjectData()
        {
            subject.SubjectName = txtSubjectName.Text;
            subject.SubjectDescription = txtSubjectDescription.Text;
            subject.LearningOutcome = txtOutcomes.Text;
            subject.YearOfStudy = int.Parse(cbxSubjectYear.Text);
            subject.Prerequisites = txtPreReq.Text;
            subject.Projects = txtSubjectProjects.Text;
            subject.StudyMaterial = txtSubjectMaterials.Text;
            subject.RolesAndResponsibilities = txtSubjectRoles.Text;


        }

        private void SubjectForm_Load(object sender, EventArgs e)
        {
            if (AddSubject)
            {
                this.Text = "Add Subject";
                txtSubjectName.ReadOnly = false;  // allow entry of new subject name
            }
            else
            {
                this.Text = "Modify Subject";
                txtSubjectName.ReadOnly = true;   // can't change existing subject name
                this.DisplaySubject();
            }
        }

        private void btnSubjectCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

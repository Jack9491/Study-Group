﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    public class StudyGroup
    {
        public int GroupId { get; set; }
        public string Name { get; set; }
        public List<Student> Members { get; set; }
        public List<Sessions> sessions { get; set; }


        public StudyGroup() { }

        public StudyGroup(int groupId, string name, List<Sessions>SessionsList, List<Student>member) 
        {
            this.GroupId = groupId;
            this.Name = name;
            this.Members = member;
            this.sessions = SessionsList;
        }


    }
}

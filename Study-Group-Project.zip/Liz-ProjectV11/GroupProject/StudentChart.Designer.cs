﻿namespace GroupProject
{
    partial class StudentChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            StudentPressentChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            btnStudentChartExit = new Button();
            ((System.ComponentModel.ISupportInitialize)StudentPressentChart).BeginInit();
            SuspendLayout();
            // 
            // StudentPressentChart
            // 
            chartArea1.Name = "ChartArea1";
            StudentPressentChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            StudentPressentChart.Legends.Add(legend1);
            StudentPressentChart.Location = new Point(80, 30);
            StudentPressentChart.Margin = new Padding(4);
            StudentPressentChart.Name = "StudentPressentChart";
            StudentPressentChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            StudentPressentChart.PaletteCustomColors = (new Color[] { SystemColors.MenuHighlight, Color.Pink });
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            StudentPressentChart.Series.Add(series1);
            StudentPressentChart.Size = new Size(469, 469);
            StudentPressentChart.TabIndex = 0;
            StudentPressentChart.Text = "StudentPressentChart";
            StudentPressentChart.Click += chart1_Click;
            // 
            // btnStudentChartExit
            // 
            btnStudentChartExit.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnStudentChartExit.ForeColor = Color.MidnightBlue;
            btnStudentChartExit.Location = new Point(230, 520);
            btnStudentChartExit.Margin = new Padding(4);
            btnStudentChartExit.Name = "btnStudentChartExit";
            btnStudentChartExit.Size = new Size(120, 45);
            btnStudentChartExit.TabIndex = 1;
            btnStudentChartExit.Text = "&Exit";
            btnStudentChartExit.UseVisualStyleBackColor = true;
            btnStudentChartExit.Click += btnStudentChartExit_Click;
            // 
            // StudentChart
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(623, 589);
            Controls.Add(btnStudentChartExit);
            Controls.Add(StudentPressentChart);
            Margin = new Padding(4);
            Name = "StudentChart";
            Text = "StudentChart";
            Load += StudentChart_Load;
            ((System.ComponentModel.ISupportInitialize)StudentPressentChart).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart StudentPressentChart;
        private Button btnStudentChartExit;
    }
}
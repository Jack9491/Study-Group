﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace GroupProject
{
    public partial class SessionsChart : Form
    {
        List<Sessions> sessions = new List<Sessions>();
        public SessionsChart(List<Sessions> sessions)
        {
            InitializeComponent();
            this.sessions = sessions;
        }

        private void SessionsChart_Load(object sender, EventArgs e)
        {
            int RoomsBookedCount = sessions.Count(ses => ses.IsBooked == true);
            int RoomsNotBookedCount = sessions.Count(ses => ses.IsBooked == false);


            SessionsRoomBookedChart.Series.Clear();
            SessionsRoomBookedChart.Series.Add("Booked");
            SessionsRoomBookedChart.Series["Booked"].ChartType = SeriesChartType.Doughnut;


            SessionsRoomBookedChart.Series["Booked"].Points.AddXY("Booked", RoomsBookedCount);
            SessionsRoomBookedChart.Series["Booked"].Points.AddXY("Availibility", RoomsNotBookedCount);


            SessionsRoomBookedChart.Titles.Add("Booked");
            SessionsRoomBookedChart.Series["Booked"].BorderWidth = 5;

            SessionsRoomBookedChart.Series["Booked"].Color = Color.Green;
            SessionsRoomBookedChart.Series["Booked"].BorderWidth = 5;
            SessionsRoomBookedChart.Series["Booked"].MarkerStyle = MarkerStyle.Diamond;
            SessionsRoomBookedChart.Series["Booked"].MarkerSize = 5;
            SessionsRoomBookedChart.Series["Booked"].MarkerColor = Color.Green;

            SessionsRoomBookedChart.Legends.Add("Booked");
            SessionsRoomBookedChart.Legends[0].LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Table;
            SessionsRoomBookedChart.Legends[0].Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            SessionsRoomBookedChart.Legends[0].Alignment = StringAlignment.Center;
            SessionsRoomBookedChart.Legends[0].Title = "Booked";
            SessionsRoomBookedChart.Legends[0].BorderColor = Color.Black;
        }

        private void btnSessionChartExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

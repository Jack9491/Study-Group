﻿namespace GroupProject
{
    partial class SubjectChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            SubjectYearChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            btnSubjectChartExit = new Button();
            ((System.ComponentModel.ISupportInitialize)SubjectYearChart).BeginInit();
            SuspendLayout();
            // 
            // SubjectYearChart
            // 
            chartArea1.Name = "ChartArea1";
            SubjectYearChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            SubjectYearChart.Legends.Add(legend1);
            SubjectYearChart.Location = new Point(80, 30);
            SubjectYearChart.Margin = new Padding(4);
            SubjectYearChart.Name = "SubjectYearChart";
            SubjectYearChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None;
            SubjectYearChart.PaletteCustomColors = (new Color[] { Color.Yellow, Color.Blue, Color.LightGray, Color.FromArgb(255, 128, 0) });
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            SubjectYearChart.Series.Add(series1);
            SubjectYearChart.Size = new Size(469, 469);
            SubjectYearChart.TabIndex = 0;
            SubjectYearChart.Text = "SubjectYearChart";
            SubjectYearChart.Click += chart1_Click;
            // 
            // btnSubjectChartExit
            // 
            btnSubjectChartExit.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnSubjectChartExit.ForeColor = Color.MidnightBlue;
            btnSubjectChartExit.Location = new Point(240, 520);
            btnSubjectChartExit.Margin = new Padding(4);
            btnSubjectChartExit.Name = "btnSubjectChartExit";
            btnSubjectChartExit.Size = new Size(120, 45);
            btnSubjectChartExit.TabIndex = 1;
            btnSubjectChartExit.Text = "&Exit";
            btnSubjectChartExit.UseVisualStyleBackColor = true;
            btnSubjectChartExit.Click += btnSubjectChartExit_Click;
            // 
            // SubjectChart
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(623, 589);
            Controls.Add(btnSubjectChartExit);
            Controls.Add(SubjectYearChart);
            Margin = new Padding(4);
            Name = "SubjectChart";
            Text = "SubjectChart";
            Load += SubjectChart_Load;
            ((System.ComponentModel.ISupportInitialize)SubjectYearChart).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart SubjectYearChart;
        private Button btnSubjectChartExit;
    }
}
﻿namespace GroupProject
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            tabHome = new TabControl();
            tabHomePage = new TabPage();
            panel2 = new Panel();
            label1 = new Label();
            rtbHomeBox3 = new RichTextBox();
            lblHomeAddSes = new Label();
            lblHomeAddSub = new Label();
            lblHomeAddStud = new Label();
            btnHomeAddSes = new Button();
            btnHomeAddSub = new Button();
            btnHomeStud = new Button();
            lblHomeSubHeading3 = new Label();
            panel1 = new Panel();
            lblHomeHR1 = new Label();
            rtbHomeBox2 = new RichTextBox();
            rtbHomeBox1 = new RichTextBox();
            lblHomeSubHeading2 = new Label();
            lblHomeSubHeading1 = new Label();
            lblHomePageTitle = new Label();
            tabStudent = new TabPage();
            btnShowStudentChart = new Button();
            btnSearchStudent = new Button();
            txtSearchStudent = new TextBox();
            btnCopyStud = new Button();
            lblStudentTabTitle = new Label();
            btnAddStudentHome = new Button();
            dgvStudent = new DataGridView();
            tabSubject = new TabPage();
            btnChartSubject = new Button();
            btnSearchSubject = new Button();
            txtSearchSubject = new TextBox();
            btnCopySub = new Button();
            lblSubjectTabTitle = new Label();
            btnAddSubjectHome = new Button();
            dgvSubject = new DataGridView();
            tabSessions = new TabPage();
            btnShowChartRoomBooked = new Button();
            btnSearchSession = new Button();
            txtSearchSession = new TextBox();
            btnCopySession = new Button();
            lblSessionTabTitle = new Label();
            btnAddSessionHome = new Button();
            dgvSessions = new DataGridView();
            tabHome.SuspendLayout();
            tabHomePage.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            tabStudent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStudent).BeginInit();
            tabSubject.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSubject).BeginInit();
            tabSessions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSessions).BeginInit();
            SuspendLayout();
            // 
            // tabHome
            // 
            tabHome.Controls.Add(tabHomePage);
            tabHome.Controls.Add(tabStudent);
            tabHome.Controls.Add(tabSubject);
            tabHome.Controls.Add(tabSessions);
            tabHome.Location = new Point(0, 0);
            tabHome.Margin = new Padding(4);
            tabHome.Name = "tabHome";
            tabHome.SelectedIndex = 0;
            tabHome.Size = new Size(998, 484);
            tabHome.TabIndex = 0;
            tabHome.SelectedIndexChanged += tabStudent_Click;
            // 
            // tabHomePage
            // 
            tabHomePage.Controls.Add(panel2);
            tabHomePage.Controls.Add(panel1);
            tabHomePage.Location = new Point(4, 34);
            tabHomePage.Name = "tabHomePage";
            tabHomePage.Size = new Size(990, 446);
            tabHomePage.TabIndex = 3;
            tabHomePage.Text = "Home";
            tabHomePage.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(label1);
            panel2.Controls.Add(rtbHomeBox3);
            panel2.Controls.Add(lblHomeAddSes);
            panel2.Controls.Add(lblHomeAddSub);
            panel2.Controls.Add(lblHomeAddStud);
            panel2.Controls.Add(btnHomeAddSes);
            panel2.Controls.Add(btnHomeAddSub);
            panel2.Controls.Add(btnHomeStud);
            panel2.Controls.Add(lblHomeSubHeading3);
            panel2.Location = new Point(506, 33);
            panel2.Name = "panel2";
            panel2.Size = new Size(460, 395);
            panel2.TabIndex = 1;
            // 
            // label1
            // 
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Font = new Font("Century Gothic", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.MidnightBlue;
            label1.Location = new Point(17, 63);
            label1.Name = "label1";
            label1.Size = new Size(420, 2);
            label1.TabIndex = 13;
            // 
            // rtbHomeBox3
            // 
            rtbHomeBox3.Location = new Point(47, 292);
            rtbHomeBox3.Name = "rtbHomeBox3";
            rtbHomeBox3.Size = new Size(380, 81);
            rtbHomeBox3.TabIndex = 7;
            rtbHomeBox3.Text = "";
            // 
            // lblHomeAddSes
            // 
            lblHomeAddSes.AutoSize = true;
            lblHomeAddSes.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblHomeAddSes.ForeColor = Color.MidnightBlue;
            lblHomeAddSes.Location = new Point(219, 223);
            lblHomeAddSes.Name = "lblHomeAddSes";
            lblHomeAddSes.Size = new Size(133, 22);
            lblHomeAddSes.TabIndex = 6;
            lblHomeAddSes.Text = "Add a Session";
            // 
            // lblHomeAddSub
            // 
            lblHomeAddSub.AutoSize = true;
            lblHomeAddSub.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblHomeAddSub.ForeColor = Color.MidnightBlue;
            lblHomeAddSub.Location = new Point(219, 152);
            lblHomeAddSub.Name = "lblHomeAddSub";
            lblHomeAddSub.Size = new Size(135, 22);
            lblHomeAddSub.TabIndex = 5;
            lblHomeAddSub.Text = "Add a Subject";
            // 
            // lblHomeAddStud
            // 
            lblHomeAddStud.AutoSize = true;
            lblHomeAddStud.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblHomeAddStud.ForeColor = Color.MidnightBlue;
            lblHomeAddStud.Location = new Point(219, 88);
            lblHomeAddStud.Name = "lblHomeAddStud";
            lblHomeAddStud.Size = new Size(134, 22);
            lblHomeAddStud.TabIndex = 4;
            lblHomeAddStud.Text = "Add a Student";
            // 
            // btnHomeAddSes
            // 
            btnHomeAddSes.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnHomeAddSes.Location = new Point(45, 214);
            btnHomeAddSes.Name = "btnHomeAddSes";
            btnHomeAddSes.Size = new Size(112, 34);
            btnHomeAddSes.TabIndex = 3;
            btnHomeAddSes.Text = "&Add";
            btnHomeAddSes.UseVisualStyleBackColor = true;
            btnHomeAddSes.Click += btnHomeAddSes_Click;
            // 
            // btnHomeAddSub
            // 
            btnHomeAddSub.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnHomeAddSub.Location = new Point(45, 147);
            btnHomeAddSub.Name = "btnHomeAddSub";
            btnHomeAddSub.Size = new Size(112, 34);
            btnHomeAddSub.TabIndex = 2;
            btnHomeAddSub.Text = "&Add";
            btnHomeAddSub.UseVisualStyleBackColor = true;
            btnHomeAddSub.Click += btnHomeAddSub_Click;
            // 
            // btnHomeStud
            // 
            btnHomeStud.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnHomeStud.Location = new Point(45, 88);
            btnHomeStud.Name = "btnHomeStud";
            btnHomeStud.Size = new Size(112, 34);
            btnHomeStud.TabIndex = 1;
            btnHomeStud.Text = "&Add";
            btnHomeStud.UseVisualStyleBackColor = true;
            btnHomeStud.Click += btnHomeStud_Click;
            // 
            // lblHomeSubHeading3
            // 
            lblHomeSubHeading3.AutoSize = true;
            lblHomeSubHeading3.Font = new Font("Century Gothic", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lblHomeSubHeading3.ForeColor = Color.MidnightBlue;
            lblHomeSubHeading3.Location = new Point(170, 20);
            lblHomeSubHeading3.Name = "lblHomeSubHeading3";
            lblHomeSubHeading3.Size = new Size(110, 23);
            lblHomeSubHeading3.TabIndex = 0;
            lblHomeSubHeading3.Text = "Test it Out!";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gainsboro;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(lblHomeHR1);
            panel1.Controls.Add(rtbHomeBox2);
            panel1.Controls.Add(rtbHomeBox1);
            panel1.Controls.Add(lblHomeSubHeading2);
            panel1.Controls.Add(lblHomeSubHeading1);
            panel1.Controls.Add(lblHomePageTitle);
            panel1.Location = new Point(19, 33);
            panel1.Name = "panel1";
            panel1.Size = new Size(460, 395);
            panel1.TabIndex = 0;
            // 
            // lblHomeHR1
            // 
            lblHomeHR1.BorderStyle = BorderStyle.Fixed3D;
            lblHomeHR1.Font = new Font("Century Gothic", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lblHomeHR1.ForeColor = Color.MidnightBlue;
            lblHomeHR1.Location = new Point(15, 73);
            lblHomeHR1.Name = "lblHomeHR1";
            lblHomeHR1.Size = new Size(420, 2);
            lblHomeHR1.TabIndex = 12;
            // 
            // rtbHomeBox2
            // 
            rtbHomeBox2.Location = new Point(15, 238);
            rtbHomeBox2.Name = "rtbHomeBox2";
            rtbHomeBox2.Size = new Size(379, 121);
            rtbHomeBox2.TabIndex = 11;
            rtbHomeBox2.Text = "In each tab, the user can Add a new Student/Subject/Session, Copy the details of the DGV, Search through the details of the DGV, and view a Graph of each DGV.";
            // 
            // rtbHomeBox1
            // 
            rtbHomeBox1.Location = new Point(15, 113);
            rtbHomeBox1.Name = "rtbHomeBox1";
            rtbHomeBox1.Size = new Size(379, 68);
            rtbHomeBox1.TabIndex = 10;
            rtbHomeBox1.Text = "This application is to help students organise study groups more efficently.";
            // 
            // lblHomeSubHeading2
            // 
            lblHomeSubHeading2.AutoSize = true;
            lblHomeSubHeading2.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblHomeSubHeading2.ForeColor = Color.MidnightBlue;
            lblHomeSubHeading2.Location = new Point(15, 204);
            lblHomeSubHeading2.Name = "lblHomeSubHeading2";
            lblHomeSubHeading2.Size = new Size(120, 22);
            lblHomeSubHeading2.TabIndex = 8;
            lblHomeSubHeading2.Text = "Functionality";
            // 
            // lblHomeSubHeading1
            // 
            lblHomeSubHeading1.AutoSize = true;
            lblHomeSubHeading1.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblHomeSubHeading1.ForeColor = Color.MidnightBlue;
            lblHomeSubHeading1.Location = new Point(15, 88);
            lblHomeSubHeading1.Name = "lblHomeSubHeading1";
            lblHomeSubHeading1.Size = new Size(223, 22);
            lblHomeSubHeading1.TabIndex = 6;
            lblHomeSubHeading1.Text = "What can it be used for?";
            // 
            // lblHomePageTitle
            // 
            lblHomePageTitle.AutoSize = true;
            lblHomePageTitle.Font = new Font("Century Gothic", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lblHomePageTitle.ForeColor = Color.MidnightBlue;
            lblHomePageTitle.Location = new Point(85, 20);
            lblHomePageTitle.Name = "lblHomePageTitle";
            lblHomePageTitle.Size = new Size(249, 46);
            lblHomePageTitle.TabIndex = 5;
            lblHomePageTitle.Text = "Welcome to the \r\nStudy Group Application";
            lblHomePageTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tabStudent
            // 
            tabStudent.Controls.Add(btnShowStudentChart);
            tabStudent.Controls.Add(btnSearchStudent);
            tabStudent.Controls.Add(txtSearchStudent);
            tabStudent.Controls.Add(btnCopyStud);
            tabStudent.Controls.Add(lblStudentTabTitle);
            tabStudent.Controls.Add(btnAddStudentHome);
            tabStudent.Controls.Add(dgvStudent);
            tabStudent.Location = new Point(4, 34);
            tabStudent.Margin = new Padding(4);
            tabStudent.Name = "tabStudent";
            tabStudent.Padding = new Padding(4);
            tabStudent.Size = new Size(990, 446);
            tabStudent.TabIndex = 0;
            tabStudent.Text = "Student";
            tabStudent.UseVisualStyleBackColor = true;
            tabStudent.Click += tabStudent_Click;
            // 
            // btnShowStudentChart
            // 
            btnShowStudentChart.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnShowStudentChart.ForeColor = Color.MidnightBlue;
            btnShowStudentChart.Location = new Point(360, 380);
            btnShowStudentChart.Name = "btnShowStudentChart";
            btnShowStudentChart.Size = new Size(270, 60);
            btnShowStudentChart.TabIndex = 6;
            btnShowStudentChart.Text = "Show Chart of Present Students";
            btnShowStudentChart.UseVisualStyleBackColor = true;
            btnShowStudentChart.Click += btnShowStudentChart_Click;
            // 
            // btnSearchStudent
            // 
            btnSearchStudent.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnSearchStudent.ForeColor = Color.MidnightBlue;
            btnSearchStudent.Location = new Point(884, 15);
            btnSearchStudent.Margin = new Padding(4);
            btnSearchStudent.Name = "btnSearchStudent";
            btnSearchStudent.Size = new Size(90, 30);
            btnSearchStudent.TabIndex = 5;
            btnSearchStudent.Text = "search";
            btnSearchStudent.UseVisualStyleBackColor = true;
            btnSearchStudent.Click += btnSearchStudent_Click;
            // 
            // txtSearchStudent
            // 
            txtSearchStudent.Location = new Point(567, 15);
            txtSearchStudent.Name = "txtSearchStudent";
            txtSearchStudent.PlaceholderText = "Search through the DataGridView...";
            txtSearchStudent.Size = new Size(310, 31);
            txtSearchStudent.TabIndex = 4;
            // 
            // btnCopyStud
            // 
            btnCopyStud.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnCopyStud.ForeColor = Color.MidnightBlue;
            btnCopyStud.Location = new Point(43, 390);
            btnCopyStud.Margin = new Padding(4);
            btnCopyStud.Name = "btnCopyStud";
            btnCopyStud.Size = new Size(205, 35);
            btnCopyStud.TabIndex = 3;
            btnCopyStud.Text = "Copy Student";
            btnCopyStud.UseVisualStyleBackColor = true;
            btnCopyStud.Click += btnCopyStud_Click;
            // 
            // lblStudentTabTitle
            // 
            lblStudentTabTitle.AutoSize = true;
            lblStudentTabTitle.Font = new Font("Century Gothic", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lblStudentTabTitle.ForeColor = Color.MidnightBlue;
            lblStudentTabTitle.Location = new Point(20, 15);
            lblStudentTabTitle.Name = "lblStudentTabTitle";
            lblStudentTabTitle.Size = new Size(273, 23);
            lblStudentTabTitle.TabIndex = 2;
            lblStudentTabTitle.Text = "Study Group | Add Student";
            // 
            // btnAddStudentHome
            // 
            btnAddStudentHome.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddStudentHome.ForeColor = Color.MidnightBlue;
            btnAddStudentHome.Location = new Point(730, 390);
            btnAddStudentHome.Margin = new Padding(4);
            btnAddStudentHome.Name = "btnAddStudentHome";
            btnAddStudentHome.Size = new Size(205, 35);
            btnAddStudentHome.TabIndex = 1;
            btnAddStudentHome.Text = "Add Student";
            btnAddStudentHome.UseVisualStyleBackColor = true;
            btnAddStudentHome.Click += btnAddStudentHome_Click;
            // 
            // dgvStudent
            // 
            dgvStudent.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStudent.Location = new Point(20, 50);
            dgvStudent.Margin = new Padding(4);
            dgvStudent.Name = "dgvStudent";
            dgvStudent.RowHeadersWidth = 51;
            dgvStudent.RowTemplate.Height = 29;
            dgvStudent.Size = new Size(960, 320);
            dgvStudent.TabIndex = 0;
            dgvStudent.CellContentClick += dgvStudent_CellContentClick;
            // 
            // tabSubject
            // 
            tabSubject.Controls.Add(btnChartSubject);
            tabSubject.Controls.Add(btnSearchSubject);
            tabSubject.Controls.Add(txtSearchSubject);
            tabSubject.Controls.Add(btnCopySub);
            tabSubject.Controls.Add(lblSubjectTabTitle);
            tabSubject.Controls.Add(btnAddSubjectHome);
            tabSubject.Controls.Add(dgvSubject);
            tabSubject.Location = new Point(4, 34);
            tabSubject.Margin = new Padding(4);
            tabSubject.Name = "tabSubject";
            tabSubject.Padding = new Padding(4);
            tabSubject.Size = new Size(990, 446);
            tabSubject.TabIndex = 1;
            tabSubject.Text = "Subject";
            tabSubject.UseVisualStyleBackColor = true;
            tabSubject.Click += tabSubject_Click;
            // 
            // btnChartSubject
            // 
            btnChartSubject.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnChartSubject.ForeColor = Color.MidnightBlue;
            btnChartSubject.Location = new Point(360, 380);
            btnChartSubject.Name = "btnChartSubject";
            btnChartSubject.Size = new Size(270, 60);
            btnChartSubject.TabIndex = 8;
            btnChartSubject.Text = "Show Chart of Subject Year";
            btnChartSubject.UseVisualStyleBackColor = true;
            btnChartSubject.Click += btnChartSubject_Click;
            // 
            // btnSearchSubject
            // 
            btnSearchSubject.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnSearchSubject.ForeColor = Color.MidnightBlue;
            btnSearchSubject.Location = new Point(886, 15);
            btnSearchSubject.Margin = new Padding(4);
            btnSearchSubject.Name = "btnSearchSubject";
            btnSearchSubject.Size = new Size(90, 30);
            btnSearchSubject.TabIndex = 7;
            btnSearchSubject.Text = "search";
            btnSearchSubject.UseVisualStyleBackColor = true;
            btnSearchSubject.Click += btnSearchSubject_Click;
            // 
            // txtSearchSubject
            // 
            txtSearchSubject.Location = new Point(569, 15);
            txtSearchSubject.Name = "txtSearchSubject";
            txtSearchSubject.PlaceholderText = "Search through the DataGridView...";
            txtSearchSubject.Size = new Size(310, 31);
            txtSearchSubject.TabIndex = 6;
            // 
            // btnCopySub
            // 
            btnCopySub.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnCopySub.ForeColor = Color.MidnightBlue;
            btnCopySub.Location = new Point(44, 390);
            btnCopySub.Margin = new Padding(4);
            btnCopySub.Name = "btnCopySub";
            btnCopySub.Size = new Size(205, 35);
            btnCopySub.TabIndex = 5;
            btnCopySub.Text = "Copy Subject";
            btnCopySub.UseVisualStyleBackColor = true;
            btnCopySub.Click += btnCopySub_Click;
            // 
            // lblSubjectTabTitle
            // 
            lblSubjectTabTitle.AutoSize = true;
            lblSubjectTabTitle.Font = new Font("Century Gothic", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lblSubjectTabTitle.ForeColor = Color.MidnightBlue;
            lblSubjectTabTitle.Location = new Point(20, 15);
            lblSubjectTabTitle.Name = "lblSubjectTabTitle";
            lblSubjectTabTitle.Size = new Size(273, 23);
            lblSubjectTabTitle.TabIndex = 4;
            lblSubjectTabTitle.Text = "Study Group | Add Subject";
            // 
            // btnAddSubjectHome
            // 
            btnAddSubjectHome.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddSubjectHome.ForeColor = Color.MidnightBlue;
            btnAddSubjectHome.Location = new Point(730, 390);
            btnAddSubjectHome.Margin = new Padding(4);
            btnAddSubjectHome.Name = "btnAddSubjectHome";
            btnAddSubjectHome.Size = new Size(205, 35);
            btnAddSubjectHome.TabIndex = 3;
            btnAddSubjectHome.Text = "Add Subject";
            btnAddSubjectHome.UseVisualStyleBackColor = true;
            btnAddSubjectHome.Click += btnAddSubjectHome_Click;
            // 
            // dgvSubject
            // 
            dgvSubject.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSubject.Location = new Point(20, 50);
            dgvSubject.Margin = new Padding(4);
            dgvSubject.Name = "dgvSubject";
            dgvSubject.RowHeadersWidth = 51;
            dgvSubject.RowTemplate.Height = 29;
            dgvSubject.Size = new Size(960, 320);
            dgvSubject.TabIndex = 2;
            dgvSubject.CellContentClick += dgvSubject_CellContentClick;
            // 
            // tabSessions
            // 
            tabSessions.Controls.Add(btnShowChartRoomBooked);
            tabSessions.Controls.Add(btnSearchSession);
            tabSessions.Controls.Add(txtSearchSession);
            tabSessions.Controls.Add(btnCopySession);
            tabSessions.Controls.Add(lblSessionTabTitle);
            tabSessions.Controls.Add(btnAddSessionHome);
            tabSessions.Controls.Add(dgvSessions);
            tabSessions.Location = new Point(4, 34);
            tabSessions.Margin = new Padding(4);
            tabSessions.Name = "tabSessions";
            tabSessions.Padding = new Padding(4);
            tabSessions.Size = new Size(990, 446);
            tabSessions.TabIndex = 2;
            tabSessions.Text = "Sessions";
            tabSessions.UseVisualStyleBackColor = true;
            tabSessions.Click += tabSessions_Click;
            // 
            // btnShowChartRoomBooked
            // 
            btnShowChartRoomBooked.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnShowChartRoomBooked.ForeColor = Color.MidnightBlue;
            btnShowChartRoomBooked.Location = new Point(360, 380);
            btnShowChartRoomBooked.Name = "btnShowChartRoomBooked";
            btnShowChartRoomBooked.Size = new Size(270, 60);
            btnShowChartRoomBooked.TabIndex = 10;
            btnShowChartRoomBooked.Text = "Show Chart of Room Availability";
            btnShowChartRoomBooked.UseVisualStyleBackColor = true;
            btnShowChartRoomBooked.Click += btnShowChartRoomBooked_Click;
            // 
            // btnSearchSession
            // 
            btnSearchSession.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnSearchSession.ForeColor = Color.MidnightBlue;
            btnSearchSession.Location = new Point(887, 15);
            btnSearchSession.Margin = new Padding(4);
            btnSearchSession.Name = "btnSearchSession";
            btnSearchSession.Size = new Size(90, 30);
            btnSearchSession.TabIndex = 9;
            btnSearchSession.Text = "search";
            btnSearchSession.UseVisualStyleBackColor = true;
            btnSearchSession.Click += btnSearchSession_Click;
            // 
            // txtSearchSession
            // 
            txtSearchSession.Location = new Point(570, 15);
            txtSearchSession.Name = "txtSearchSession";
            txtSearchSession.PlaceholderText = "Search through the DataGridView...";
            txtSearchSession.Size = new Size(310, 31);
            txtSearchSession.TabIndex = 8;
            // 
            // btnCopySession
            // 
            btnCopySession.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnCopySession.ForeColor = Color.MidnightBlue;
            btnCopySession.Location = new Point(45, 390);
            btnCopySession.Margin = new Padding(4);
            btnCopySession.Name = "btnCopySession";
            btnCopySession.Size = new Size(205, 35);
            btnCopySession.TabIndex = 5;
            btnCopySession.Text = "Copy Session";
            btnCopySession.UseVisualStyleBackColor = true;
            btnCopySession.Click += btnCopySession_Click;
            // 
            // lblSessionTabTitle
            // 
            lblSessionTabTitle.AutoSize = true;
            lblSessionTabTitle.BackColor = Color.Transparent;
            lblSessionTabTitle.Font = new Font("Century Gothic", 10F, FontStyle.Bold, GraphicsUnit.Point);
            lblSessionTabTitle.ForeColor = Color.MidnightBlue;
            lblSessionTabTitle.Location = new Point(20, 15);
            lblSessionTabTitle.Name = "lblSessionTabTitle";
            lblSessionTabTitle.Size = new Size(272, 23);
            lblSessionTabTitle.TabIndex = 4;
            lblSessionTabTitle.Text = "Study Group | Add Session";
            // 
            // btnAddSessionHome
            // 
            btnAddSessionHome.Font = new Font("Consolas", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddSessionHome.ForeColor = Color.MidnightBlue;
            btnAddSessionHome.Location = new Point(730, 390);
            btnAddSessionHome.Margin = new Padding(4);
            btnAddSessionHome.Name = "btnAddSessionHome";
            btnAddSessionHome.Size = new Size(205, 35);
            btnAddSessionHome.TabIndex = 3;
            btnAddSessionHome.Text = "Add Session";
            btnAddSessionHome.UseVisualStyleBackColor = true;
            btnAddSessionHome.Click += btnAddSessionHome_Click;
            // 
            // dgvSessions
            // 
            dgvSessions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSessions.Location = new Point(20, 50);
            dgvSessions.Margin = new Padding(4);
            dgvSessions.Name = "dgvSessions";
            dgvSessions.RowHeadersWidth = 51;
            dgvSessions.RowTemplate.Height = 29;
            dgvSessions.Size = new Size(960, 320);
            dgvSessions.TabIndex = 2;
            dgvSessions.CellContentClick += dgvSessions_CellContentClick;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1012, 484);
            Controls.Add(tabHome);
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "Home";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Study Group | Home";
            Load += Home_Load;
            tabHome.ResumeLayout(false);
            tabHomePage.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            tabStudent.ResumeLayout(false);
            tabStudent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStudent).EndInit();
            tabSubject.ResumeLayout(false);
            tabSubject.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSubject).EndInit();
            tabSessions.ResumeLayout(false);
            tabSessions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSessions).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabHome;
        private TabPage tabStudent;
        private Button btnAddStudentHome;
        private DataGridView dgvStudent;
        private TabPage tabSubject;
        private TabPage tabSessions;
        private Button btnAddSubjectHome;
        private DataGridView dgvSubject;
        private Button btnAddSessionHome;
        private DataGridView dgvSessions;
        private Label lblStudentTabTitle;
        private Label lblSubjectTabTitle;
        private Label lblSessionTabTitle;
        private Button btnCopyStud;
        private Button btnCopySub;
        private Button btnCopySession;
        private Button btnSearchStudent;
        private TextBox txtSearchStudent;
        private Button btnSearchSubject;
        private TextBox txtSearchSubject;
        private Button btnSearchSession;
        private TextBox txtSearchSession;
        private TabPage tabHomePage;
        private Panel panel2;
        private RichTextBox rtbHomeBox3;
        private Label lblHomeAddSes;
        private Label lblHomeAddSub;
        private Label lblHomeAddStud;
        private Button btnHomeAddSes;
        private Button btnHomeAddSub;
        private Button btnHomeStud;
        private Label lblHomeSubHeading3;
        private Panel panel1;
        private RichTextBox rtbHomeBox2;
        private RichTextBox rtbHomeBox1;
        private Label lblHomeSubHeading2;
        private Label lblHomeSubHeading1;
        private Label lblHomePageTitle;
        private Label label1;
        private Label lblHomeHR1;
        private Button btnShowStudentChart;
        private Button btnChartSubject;
        private Button btnShowChartRoomBooked;
    }
}
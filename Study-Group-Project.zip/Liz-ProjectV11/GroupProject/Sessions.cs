﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    public class Sessions
    { 
        public string SessionName { get; set; }
        public DateTime DateAndTime { get; set; }

        public int RoomNum { get; set; }

        public string Topic { get; set; }

        public string GroupMembers { get; set; }

        public string AssignmentQs { get; set; }

        public string Agenda { get; set; }

        //public string StudyMaterials { get; set; }

        public bool IsBooked { get; set; }

        public Sessions() { }
        public Sessions(string sessionName, DateTime dateTime, int RoomNr, string SesTopic, string GrpMem, string AssQs, string SesAgenda, bool SesIsBooked) 
        {
            this.SessionName = sessionName;
            this.DateAndTime = dateTime;
            this.RoomNum = RoomNr;
            this.Topic = SesTopic;
            this.GroupMembers = GrpMem;
            this.AssignmentQs = AssQs;
            this.Agenda = SesAgenda;
            this.IsBooked = SesIsBooked;
            
        }

    }
}

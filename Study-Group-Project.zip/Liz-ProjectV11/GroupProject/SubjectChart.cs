﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace GroupProject
{
    public partial class SubjectChart : Form
    {
        List<Subject> subjects = new List<Subject>();
        public SubjectChart(List<Subject> subjects)
        {
            InitializeComponent();
            this.subjects = subjects;
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void SubjectChart_Load(object sender, EventArgs e)
        {
            int Year1Count = subjects.Count(sub => sub.YearOfStudy == 1);
            int Year2Count = subjects.Count(sub => sub.YearOfStudy == 2);
            int Year3Count = subjects.Count(sub => sub.YearOfStudy == 3);
            int Year4Count = subjects.Count(sub => sub.YearOfStudy == 4);



            SubjectYearChart.Series.Clear();
            SubjectYearChart.Series.Add("Year");
            SubjectYearChart.Series["Year"].ChartType = SeriesChartType.Bar;


            SubjectYearChart.Series["Year"].Points.AddXY("Year 1", Year1Count);
            SubjectYearChart.Series["Year"].Points.AddXY("Year 2", Year2Count);
            SubjectYearChart.Series["Year"].Points.AddXY("Year 3", Year3Count);
            SubjectYearChart.Series["Year"].Points.AddXY("Year 4", Year4Count);


            SubjectYearChart.Titles.Add("Year");
            SubjectYearChart.Series["Year"].BorderWidth = 5;

            SubjectYearChart.Series["Year"].Color = Color.Green;
            SubjectYearChart.Series["Year"].BorderWidth = 5;
            SubjectYearChart.Series["Year"].MarkerStyle = MarkerStyle.Diamond;
            SubjectYearChart.Series["Year"].MarkerSize = 5;
            SubjectYearChart.Series["Year"].MarkerColor = Color.Green;

            SubjectYearChart.Legends.Add("  Year Display");
            SubjectYearChart.Legends[0].LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Table;
            SubjectYearChart.Legends[0].Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            SubjectYearChart.Legends[0].Alignment = StringAlignment.Center;
            SubjectYearChart.Legends[0].Title = "Year Display";
            SubjectYearChart.Legends[0].BorderColor = Color.Black;
        }

        private void btnSubjectChartExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

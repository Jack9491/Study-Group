﻿using System.ComponentModel;
using System.Text;
//using System.Windows.Forms.DataVisualization.Charting;

namespace GroupProject
{
    public partial class Home : Form
    {
        List<Student> students = new List<Student>();
        List<Subject> subjects = new List<Subject>();
        List<Sessions> sessions = new List<Sessions>();

        public Home()
        {
            InitializeComponent();
            loadDataToList();
        }

        private void loadDataToList()
        {
            Student s0 = new Student("K00273113", "Greg", 18, "Male", 2, "Clare", "0852433145", true, 10);
            Student s1 = new Student("K00276788", "Bill", 19, "Male", 2, "Cavan", "0852433145", false, 5);
            Student s2 = new Student("K00234453", "Eoin", 17, "Male", 1, "Sligo", "0852433145", true, 15);
            Student s3 = new Student("K00345633", "Mike", 20, "Male", 3, "Clare", "0852433145", false, 5);
            Student s4 = new Student("K00273113", "Paul", 16, "Male", 1, "Galway", "0852433145", true, 10);
            Student s5 = new Student("K00276788", "Jack", 22, "Female", 4, "Antrim", "0852433145", false, 5);
            Student s6 = new Student("K00234453", "Ryan", 25, "Female", 1, "Limerick", "0852433145", true, 20);
            Student s7 = new Student("K00345633", "John", 19, "Female", 2, "Clare", "0852433145", false, 10);

            this.students.Add(s0);
            this.students.Add(s1);
            this.students.Add(s2);
            this.students.Add(s3);
            this.students.Add(s4);
            this.students.Add(s5);
            this.students.Add(s6);
            this.students.Add(s7);

            Subject sub0 = new Subject("Maths", "Set Theory", "Chapter 2", 1, "Learn chapter 1", "3", "Calculator", "Jim is leader");
            Subject sub1 = new Subject("App Dev", "Foreach loops", "Chapter 22", 1, "Learn chapter 19", "1", "Slides 19", "Jim is leader");
            Subject sub2 = new Subject("App Dev", "Foreach loops", "Chapter 22", 3, "Learn chapter 19", "1", "Slides 19", "Jim is leader");
            Subject sub3 = new Subject("App Dev", "Foreach loops", "Chapter 22", 4, "Learn chapter 19", "1", "Slides 19", "Jim is leader");
            Subject sub4 = new Subject("App Dev", "Foreach loops", "Chapter 22", 2, "Learn chapter 19", "1", "Slides 19", "Jim is leader");
            Subject sub5 = new Subject("App Dev", "Foreach loops", "Chapter 22", 2, "Learn chapter 19", "1", "Slides 19", "Jim is leader");
            Subject sub6 = new Subject("App Dev", "Foreach loops", "Chapter 22", 2, "Learn chapter 19", "1", "Slides 19", "Jim is leader");
            Subject sub7 = new Subject("App Dev", "Foreach loops", "Chapter 22", 3, "Learn chapter 19", "1", "Slides 19", "Jim is leader");

            this.subjects.Add(sub0);
            this.subjects.Add(sub1);
            this.subjects.Add(sub2);
            this.subjects.Add(sub3);
            this.subjects.Add(sub4);
            this.subjects.Add(sub5);
            this.subjects.Add(sub6);
            this.subjects.Add(sub7);




            Sessions ses0 = new Sessions("Session1", DateTime.Parse("04/04/2023"), 18, "Maths", "Greg, Bill, Mark", "A, B and C", "Complete questions", true);
            Sessions ses1 = new Sessions("Session1", DateTime.Parse("04/04/2023"), 18, "Maths", "Greg, Bill, Mark", "A, B and C", "Complete questions", false);
            Sessions ses2 = new Sessions("Session1", DateTime.Parse("04/04/2023"), 18, "Maths", "Greg, Bill, Mark", "A, B and C", "Complete questions", true);

            this.sessions.Add(ses0);
            this.sessions.Add(ses1);
            this.sessions.Add(ses2);

        }



        private Student selectedStudent;
        private Subject selectedSubject;
        private Sessions selectedSession;


        private void Home_Load(object sender, EventArgs e)
        {

            DisplayStudents();
            DisplaySubjects();
            DisplaySessions();
        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // store index values for Modify and Delete button columns
            const int ModifyIndex = 9;
            const int DeleteIndex = 10;

            if (e.ColumnIndex == ModifyIndex || e.ColumnIndex == DeleteIndex)
            {
                string Knum = dgvStudent.Rows[e.RowIndex].Cells[0].Value.ToString().Trim();
                selectedStudent = GetStudent(Knum);
            }

            if (e.ColumnIndex == ModifyIndex)
            {
                ModifyStudent(e.RowIndex);
            }
            else if (e.ColumnIndex == DeleteIndex)
            {
                DeleteStudent();
            }
        }
        private void DeleteStudent()
        {
            DialogResult result =
                MessageBox.Show($"Delete {selectedStudent.StudentName.Trim()}?",
                "Confirm Delete", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                if (students.Remove(selectedStudent))
                {
                    DisplayStudents();
                }
            }
        }

        private void btnAddStudentHome_Click(object sender, EventArgs e)
        {
            StudentForm showStudent = new StudentForm()
            {
                AddStudent = true
            };

            DialogResult result = showStudent.ShowDialog();
            if (result == DialogResult.OK)
            {
                selectedStudent = showStudent.student;
                this.students.Add(selectedStudent);
                DisplayStudents();

            }
        }

        private void ModifyStudent(int indexOfOld)
        {

            var oldStudent = new Student
            {
                KNum = selectedStudent.KNum,
                StudentName = selectedStudent.StudentName,
                StudentAge = selectedStudent.StudentAge,
                Gender = selectedStudent.Gender,
                StudyYear = selectedStudent.StudyYear,
                County = selectedStudent.County,
                StudentPhoneNumber = selectedStudent.StudentPhoneNumber
            };
            StudentForm showStudent = new StudentForm()
            {
                AddStudent = false,
                student = selectedStudent
            };
            DialogResult result = showStudent.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.students[indexOfOld] = selectedStudent;
                DisplayStudents();

            }
        }

        private Student GetStudent(string Knum)
        {
            foreach (Student student in students)
            {
                if (student.KNum.Equals(Knum)) return student;
            }
            return null;

        }

        private void tabStudent_Click(object sender, EventArgs e)
        {
            DisplaySessions();
            DisplayStudents();
            DisplaySubjects();
        }

        private void DisplayStudents()
        {
            dgvStudent.Columns.Clear();
            dgvStudent.DataSource = new BindingList<Student>(this.students.ToList());

            // add column for modify button
            var modifyColumn = new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Modify"
            };
            dgvStudent.Columns.Add(modifyColumn);

            // add column for delete button
            var deleteColumn = new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Delete"
            };
            dgvStudent.Columns.Add(deleteColumn);

            // format the column header
            dgvStudent.EnableHeadersVisualStyles = false;
            dgvStudent.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 7, FontStyle.Bold);
            dgvStudent.ColumnHeadersDefaultCellStyle.BackColor = Color.SteelBlue;
            dgvStudent.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // format the odd numbered rows
            dgvStudent.AlternatingRowsDefaultCellStyle.BackColor = Color.LightBlue;

            // format the first Column
            dgvStudent.Columns[0].HeaderText = "Knumber";
            dgvStudent.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[0].Width = 110;
            dgvStudent.Columns[0].DefaultCellStyle.Format = "c";
            dgvStudent.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Second column
            dgvStudent.Columns[1].HeaderText = "Name";
            dgvStudent.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[1].Width = 90;
            dgvStudent.Columns[1].DefaultCellStyle.Format = "0";
            dgvStudent.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Third column
            dgvStudent.Columns[2].HeaderText = "Age";
            dgvStudent.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[2].Width = 60;
            dgvStudent.Columns[2].DefaultCellStyle.Format = "0";
            dgvStudent.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Fourth column
            dgvStudent.Columns[3].HeaderText = "Gender";
            dgvStudent.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[3].Width = 90;
            dgvStudent.Columns[3].DefaultCellStyle.Format = "c";
            dgvStudent.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Fifth column
            dgvStudent.Columns[4].HeaderText = "Year";
            dgvStudent.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[4].Width = 50;
            dgvStudent.Columns[4].DefaultCellStyle.Format = "0";
            dgvStudent.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Sixth column
            dgvStudent.Columns[5].HeaderText = "County";
            dgvStudent.Columns[5].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[5].Width = 90;
            dgvStudent.Columns[5].DefaultCellStyle.Format = "c";
            dgvStudent.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            // format the Eight column
            dgvStudent.Columns[6].HeaderText = "Phone Number";
            dgvStudent.Columns[6].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[6].Width = 110;
            dgvStudent.Columns[6].DefaultCellStyle.Format = "c";
            dgvStudent.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Eight column
            dgvStudent.Columns[7].HeaderText = "Present";
            dgvStudent.Columns[7].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[7].Width = 65;
            dgvStudent.Columns[7].DefaultCellStyle.Format = "c";
            dgvStudent.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Eight column
            dgvStudent.Columns[8].HeaderText = "Present Marks";
            dgvStudent.Columns[8].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[8].Width = 60;
            dgvStudent.Columns[8].DefaultCellStyle.Format = "0";
            dgvStudent.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Ninth column
            dgvStudent.Columns[9].HeaderText = "Modify Details";
            dgvStudent.Columns[9].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[9].Width = 90;
            dgvStudent.Columns[9].DefaultCellStyle.Format = "c";
            dgvStudent.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Tenth column
            dgvStudent.Columns[10].HeaderText = "Delete Details";
            dgvStudent.Columns[10].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvStudent.Columns[10].Width = 90;
            dgvStudent.Columns[10].DefaultCellStyle.Format = "c";
            dgvStudent.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }


        //------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void DisplaySubjects()
        {
            dgvSubject.Columns.Clear();
            dgvSubject.DataSource = new BindingList<Subject>(this.subjects.ToList());

            // add column for modify button
            var modifyColumn = new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Modify"
            };
            dgvSubject.Columns.Add(modifyColumn);

            // add column for delete button
            var deleteColumn = new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Delete"
            };
            dgvSubject.Columns.Add(deleteColumn);

            // format the column header
            dgvSubject.EnableHeadersVisualStyles = false;
            dgvSubject.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 7, FontStyle.Bold);
            dgvSubject.ColumnHeadersDefaultCellStyle.BackColor = Color.SteelBlue;
            dgvSubject.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // format the odd numbered rows
            dgvSubject.AlternatingRowsDefaultCellStyle.BackColor = Color.LightBlue;

            // format the first column
            dgvSubject.Columns[0].HeaderText = "Name";
            dgvSubject.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[0].Width = 90;
            dgvSubject.Columns[0].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Second column
            dgvSubject.Columns[1].HeaderText = "Description";
            dgvSubject.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[1].Width = 90;
            dgvSubject.Columns[1].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Third column
            dgvSubject.Columns[2].HeaderText = "Learning Outcomes";
            dgvSubject.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[2].Width = 90;
            dgvSubject.Columns[2].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Forth column
            dgvSubject.Columns[3].HeaderText = "Year";
            dgvSubject.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[3].Width = 50;
            dgvSubject.Columns[3].DefaultCellStyle.Format = "0";
            dgvSubject.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Fifth column
            dgvSubject.Columns[4].HeaderText = "Prerequisites";
            dgvSubject.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[4].Width = 110;
            dgvSubject.Columns[4].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Sixth column
            dgvSubject.Columns[5].HeaderText = "Projects";
            dgvSubject.Columns[5].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[5].Width = 90;
            dgvSubject.Columns[5].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Seventh column
            dgvSubject.Columns[6].HeaderText = "Materials";
            dgvSubject.Columns[6].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[6].Width = 90;
            dgvSubject.Columns[6].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Eight column
            dgvSubject.Columns[7].HeaderText = "Roles";
            dgvSubject.Columns[7].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[7].Width = 110;
            dgvSubject.Columns[7].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Ninth column
            dgvSubject.Columns[8].HeaderText = "Modify Details";
            dgvSubject.Columns[8].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[8].Width = 90;
            dgvSubject.Columns[8].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Tenth column
            dgvSubject.Columns[9].HeaderText = "Delete Details";
            dgvSubject.Columns[9].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSubject.Columns[9].Width = 90;
            dgvSubject.Columns[9].DefaultCellStyle.Format = "c";
            dgvSubject.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void tabSubject_Click(object sender, EventArgs e)
        {

        }

        private void dgvSubject_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // store index values for Modify and Delete button columns
            const int ModifyIndex = 8;
            const int DeleteIndex = 9;

            if (e.ColumnIndex == ModifyIndex || e.ColumnIndex == DeleteIndex)
            {
                string subjectName = dgvSubject.Rows[e.RowIndex].Cells[0].Value.ToString().Trim();
                selectedSubject = GetSubject(subjectName);
            }

            if (e.ColumnIndex == ModifyIndex)
            {
                ModifySubject(e.RowIndex);
            }
            else if (e.ColumnIndex == DeleteIndex)
            {
                DeleteSubject();
            }
        }

        private void DeleteSubject()
        {
            DialogResult result =
                MessageBox.Show($"Delete {selectedSubject.SubjectName.Trim()}?",
                "Confirm Delete", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                if (subjects.Remove(selectedSubject))
                {
                    DisplaySubjects();
                }
            }
        }


        private void ModifySubject(int indexOfOld)
        {

            var oldSubject = new Subject
            {
                SubjectName = selectedSubject.SubjectName,
                SubjectDescription = selectedSubject.SubjectDescription,
                LearningOutcome = selectedSubject.LearningOutcome,
                YearOfStudy = selectedSubject.YearOfStudy,
                Prerequisites = selectedSubject.Prerequisites,
                Projects = selectedSubject.Projects,
                StudyMaterial = selectedSubject.StudyMaterial,
                RolesAndResponsibilities = selectedSubject.RolesAndResponsibilities
            };
            SubjectForm showSubject = new SubjectForm()
            {
                AddSubject = false,
                subject = selectedSubject
            };
            DialogResult result = showSubject.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.subjects[indexOfOld] = selectedSubject;
                DisplaySubjects();

            }
        }

        private Subject GetSubject(string subjectName)
        {
            foreach (Subject subject in subjects)
            {
                if (subject.SubjectName.Equals(subjectName)) return subject;
            }
            return null;

        }

        private void btnAddSubjectHome_Click(object sender, EventArgs e)
        {
            SubjectForm showSubject = new SubjectForm()
            {
                AddSubject = true
            };

            DialogResult result = showSubject.ShowDialog();
            if (result == DialogResult.OK)
            {
                selectedSubject = showSubject.subject;
                this.subjects.Add(selectedSubject);
                DisplaySubjects();

            }
        }


        //------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void DisplaySessions()
        {
            dgvSessions.Columns.Clear();
            dgvSessions.DataSource = new BindingList<Sessions>(this.sessions.ToList());

            // add column for modify button
            var modifyColumn = new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Modify"
            };
            dgvSessions.Columns.Add(modifyColumn);

            // add column for delete button
            var deleteColumn = new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "",
                Text = "Delete"
            };
            dgvSessions.Columns.Add(deleteColumn);

            // format the column header
            dgvSessions.EnableHeadersVisualStyles = false;
            dgvSessions.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 7, FontStyle.Bold);
            dgvSessions.ColumnHeadersDefaultCellStyle.BackColor = Color.SteelBlue;
            dgvSessions.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // format the odd numbered rows
            dgvSessions.AlternatingRowsDefaultCellStyle.BackColor = Color.LightBlue;

            // format the zero column
            dgvSessions.Columns[0].HeaderText = "Name";
            dgvSessions.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[0].Width = 90;
            dgvSessions.Columns[0].DefaultCellStyle.Format = "c";
            dgvSessions.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the first column
            dgvSessions.Columns[1].HeaderText = "Date";
            dgvSessions.Columns[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[1].Width = 90;
            dgvSessions.Columns[1].DefaultCellStyle.Format = "dd/MM/yyyy";
            dgvSessions.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Second column
            dgvSessions.Columns[2].HeaderText = "Room Number";
            dgvSessions.Columns[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[2].Width = 90;
            dgvSessions.Columns[2].DefaultCellStyle.Format = "0";
            dgvSessions.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Third column
            dgvSessions.Columns[3].HeaderText = "Topic";
            dgvSessions.Columns[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[3].Width = 90;
            dgvSessions.Columns[3].DefaultCellStyle.Format = "c";
            dgvSessions.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Forth column
            dgvSessions.Columns[4].HeaderText = "Group Members";
            dgvSessions.Columns[4].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[4].Width = 50;
            dgvSessions.Columns[4].DefaultCellStyle.Format = "c";
            dgvSessions.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Fifth column
            dgvSessions.Columns[5].HeaderText = "Assignment Questions";
            dgvSessions.Columns[5].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[5].Width = 110;
            dgvSessions.Columns[5].DefaultCellStyle.Format = "0";
            dgvSessions.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the Sixth column
            dgvSessions.Columns[6].HeaderText = "Agenda";
            dgvSessions.Columns[6].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[6].Width = 90;
            dgvSessions.Columns[6].DefaultCellStyle.Format = "c";
            dgvSessions.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the seventh column
            dgvSessions.Columns[7].HeaderText = "Booked";
            dgvSessions.Columns[7].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[7].Width = 110;
            dgvSessions.Columns[7].DefaultCellStyle.Format = "c";
            dgvSessions.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the eigth column
            dgvSessions.Columns[8].HeaderText = "Modify Details";
            dgvSessions.Columns[8].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[8].Width = 90;
            dgvSessions.Columns[8].DefaultCellStyle.Format = "c";
            dgvSessions.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // format the ninth column
            dgvSessions.Columns[9].HeaderText = "Delete Details";
            dgvSessions.Columns[9].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvSessions.Columns[9].Width = 90;
            dgvSessions.Columns[9].DefaultCellStyle.Format = "c";
            dgvSessions.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void dgvSessions_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // store index values for Modify and Delete button columns
            const int ModifyIndex = 8;
            const int DeleteIndex = 9;

            if (e.ColumnIndex == ModifyIndex || e.ColumnIndex == DeleteIndex)
            {
                string sessionName = dgvSessions.Rows[e.RowIndex].Cells[0].Value.ToString().Trim();
                selectedSession = GetSession(sessionName);
            }

            if (e.ColumnIndex == ModifyIndex)
            {
                ModifySession(e.RowIndex);
            }
            else if (e.ColumnIndex == DeleteIndex)
            {
                DeleteSessions();
            }
        }

        private Sessions GetSession(string sessionName)
        {
            foreach (Sessions session in sessions)
            {
                if (session.SessionName.Equals(sessionName)) return session;
            }
            return null;
        }

        private void DeleteSessions()
        {
            DialogResult result =
                MessageBox.Show($"Delete {selectedSession.SessionName.Trim()}?",
                "Confirm Delete", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                if (sessions.Remove(selectedSession))
                {
                    DisplaySessions();
                }
            }
        }

        private void ModifySession(int indexOfOld)
        {

            var oldSessions = new Sessions
            {
                SessionName = selectedSession.SessionName,
                DateAndTime = selectedSession.DateAndTime,
                RoomNum = selectedSession.RoomNum,
                Topic = selectedSession.Topic,
                GroupMembers = selectedSession.GroupMembers,
                AssignmentQs = selectedSession.AssignmentQs,
                Agenda = selectedSession.Agenda,
                IsBooked = selectedSession.IsBooked
            };
            SessionsForm showSession = new SessionsForm()
            {
                AddSession = false,
                session = selectedSession
            };
            DialogResult result = showSession.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.sessions[indexOfOld] = selectedSession;
                DisplaySessions();

            }
        }


        private void btnAddSessionHome_Click(object sender, EventArgs e)
        {
            SessionsForm showSession = new SessionsForm()
            {
                AddSession = true
            };

            DialogResult result = showSession.ShowDialog();
            if (result == DialogResult.OK)
            {
                selectedSession = showSession.session;
                this.sessions.Add(selectedSession);
                DisplaySessions();

            }
        }

        private void tabSessions_Click(object sender, EventArgs e)
        {

        }
        //--------------------------------------------------------------------------------------------------------
        private void btnCopyStud_Click(object sender, EventArgs e)
        {

            DataGridViewSelectedCellCollection selectedCells = dgvStudent.SelectedCells;

            StringBuilder clipboardData = new StringBuilder();


            foreach (DataGridViewCell cell in selectedCells)
            {
                clipboardData.Append(cell.Value.ToString());
                clipboardData.Append('\t');
            }

            Clipboard.SetText(clipboardData.ToString());

            if (selectedCells.Count > 0)
            {
                MessageBox.Show(" Copied To Clipboard! ");
            }
            else
            {

            }
        }

        private void btnCopySub_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedCellCollection selectedCells = dgvSubject.SelectedCells;

            StringBuilder clipboardData = new StringBuilder();


            foreach (DataGridViewCell cell in selectedCells)
            {
                clipboardData.Append(cell.Value.ToString());
                clipboardData.Append('\t');
            }

            Clipboard.SetText(clipboardData.ToString());

            if (selectedCells.Count > 0)
            {
                MessageBox.Show(" Copied To Clipboard! ");
            }
            else
            {

            }
        }

        private void btnCopySession_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedCellCollection selectedCells = dgvSessions.SelectedCells;

            StringBuilder clipboardData = new StringBuilder();


            foreach (DataGridViewCell cell in selectedCells)
            {
                clipboardData.Append(cell.Value.ToString());
                clipboardData.Append('\t');
            }

            Clipboard.SetText(clipboardData.ToString());

            if (selectedCells.Count > 0)
            {
                MessageBox.Show(" Copied To Clipboard! ");
            }
            else
            {

            }
        }

        //-------------------------------------------------------------------------------------------------------------------
        private void btnSearchStudent_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearchStudent.Text.ToLower();

            List<DataGridViewRow> matchingRows = new List<DataGridViewRow>();

            foreach (DataGridViewRow row in dgvStudent.Rows)
            {
                bool matchFound = false;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm))
                    {
                        matchFound = true;
                        break;
                    }
                }

                if (matchFound)
                {
                    matchingRows.Add(row);
                }
            }

            if (matchingRows.Count > 0)
            {
                dgvStudent.ClearSelection();

                foreach (DataGridViewRow row in matchingRows)
                {
                    row.Selected = true;
                }
            }
        }

        private void btnSearchSubject_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearchSubject.Text.ToLower();

            List<DataGridViewRow> matchingRows = new List<DataGridViewRow>();

            foreach (DataGridViewRow row in dgvSubject.Rows)
            {
                bool matchFound = false;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm))
                    {
                        matchFound = true;
                        break;
                    }
                }

                if (matchFound)
                {
                    matchingRows.Add(row);
                }
            }

            if (matchingRows.Count > 0)
            {
                dgvStudent.ClearSelection();

                foreach (DataGridViewRow row in matchingRows)
                {
                    row.Selected = true;
                }
            }
        }

        private void btnSearchSession_Click(object sender, EventArgs e)
        {
            string searchTerm = txtSearchSession.Text.ToLower();

            List<DataGridViewRow> matchingRows = new List<DataGridViewRow>();

            foreach (DataGridViewRow row in dgvSessions.Rows)
            {
                bool matchFound = false;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm))
                    {
                        matchFound = true;
                        break;
                    }
                }

                if (matchFound)
                {
                    matchingRows.Add(row);
                }
            }

            if (matchingRows.Count > 0)
            {
                dgvSessions.ClearSelection();

                foreach (DataGridViewRow row in matchingRows)
                {
                    row.Selected = true;
                }
            }
        }

        private void btnShowStudentChart_Click(object sender, EventArgs e)
        {

            var StudentPieChart = new StudentChart(students);
            StudentPieChart.ShowDialog();
        }

        private void btnChartSubject_Click(object sender, EventArgs e)
        {
            var SubjectPieChart = new SubjectChart(subjects);
            SubjectPieChart.ShowDialog();
        }

        private void btnShowChartRoomBooked_Click(object sender, EventArgs e)
        {
            var SessionPieChart = new SessionsChart(sessions);
            SessionPieChart.ShowDialog();
        }

        private void btnHomeStud_Click(object sender, EventArgs e)
        {

            StudentForm showStudent = new StudentForm()
            {
                AddStudent = true
            };

            DialogResult result = showStudent.ShowDialog();
            if (result == DialogResult.OK)
            {
                selectedStudent = showStudent.student;
                this.students.Add(selectedStudent);
                DisplayStudents();

            }
        }

        private void btnHomeAddSub_Click(object sender, EventArgs e)
        {
            SubjectForm showSubject = new SubjectForm()
            {
                AddSubject = true
            };

            DialogResult result = showSubject.ShowDialog();
            if (result == DialogResult.OK)
            {
                selectedSubject = showSubject.subject;
                this.subjects.Add(selectedSubject);
                DisplaySubjects();

            }
        }

        private void btnHomeAddSes_Click(object sender, EventArgs e)
        {
            SessionsForm showSession = new SessionsForm()
            {
                AddSession = true
            };

            DialogResult result = showSession.ShowDialog();
            if (result == DialogResult.OK)
            {
                selectedSession = showSession.session;
                this.sessions.Add(selectedSession);
                DisplaySessions();

            }
        }
    }
}

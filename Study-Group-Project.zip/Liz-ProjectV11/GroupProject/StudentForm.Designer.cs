﻿namespace GroupProject
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentForm));
            lblStudentName = new Label();
            txtStudentName = new TextBox();
            txtStudentAge = new TextBox();
            lblAge = new Label();
            txtGender = new TextBox();
            lblGender = new Label();
            lblStudentYear = new Label();
            txtStudentKnum = new TextBox();
            lblStudentKnum = new Label();
            lblCounty = new Label();
            txtPresent = new TextBox();
            lblPresent = new Label();
            txtPhoneNum = new TextBox();
            lblPhoneNumber = new Label();
            cbxStudentYear = new ComboBox();
            cbxCounty = new ComboBox();
            btnAddStudent = new Button();
            btnStudentCancel = new Button();
            txtPresentMark = new TextBox();
            lblPresentMarks = new Label();
            SuspendLayout();
            // 
            // lblStudentName
            // 
            lblStudentName.AutoSize = true;
            lblStudentName.Location = new Point(36, 78);
            lblStudentName.Margin = new Padding(4, 0, 4, 0);
            lblStudentName.Name = "lblStudentName";
            lblStudentName.Size = new Size(63, 25);
            lblStudentName.TabIndex = 0;
            lblStudentName.Text = "Name:";
            // 
            // txtStudentName
            // 
            txtStudentName.Location = new Point(176, 74);
            txtStudentName.Margin = new Padding(4);
            txtStudentName.Name = "txtStudentName";
            txtStudentName.PlaceholderText = "Billy...";
            txtStudentName.Size = new Size(188, 31);
            txtStudentName.TabIndex = 1;
            txtStudentName.TextChanged += txtStudentName_TextChanged;
            // 
            // txtStudentAge
            // 
            txtStudentAge.Location = new Point(176, 116);
            txtStudentAge.Margin = new Padding(4);
            txtStudentAge.Name = "txtStudentAge";
            txtStudentAge.PlaceholderText = "19...";
            txtStudentAge.Size = new Size(188, 31);
            txtStudentAge.TabIndex = 3;
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.Location = new Point(36, 120);
            lblAge.Margin = new Padding(4, 0, 4, 0);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(48, 25);
            lblAge.TabIndex = 2;
            lblAge.Text = "Age:";
            // 
            // txtGender
            // 
            txtGender.Location = new Point(176, 158);
            txtGender.Margin = new Padding(4);
            txtGender.Name = "txtGender";
            txtGender.PlaceholderText = "Male/Female...";
            txtGender.Size = new Size(188, 31);
            txtGender.TabIndex = 5;
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.Location = new Point(36, 162);
            lblGender.Margin = new Padding(4, 0, 4, 0);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(73, 25);
            lblGender.TabIndex = 4;
            lblGender.Text = "Gender:";
            // 
            // lblStudentYear
            // 
            lblStudentYear.AutoSize = true;
            lblStudentYear.Location = new Point(36, 204);
            lblStudentYear.Margin = new Padding(4, 0, 4, 0);
            lblStudentYear.Name = "lblStudentYear";
            lblStudentYear.Size = new Size(114, 25);
            lblStudentYear.TabIndex = 6;
            lblStudentYear.Text = "Student Year:";
            // 
            // txtStudentKnum
            // 
            txtStudentKnum.Location = new Point(176, 32);
            txtStudentKnum.Margin = new Padding(4);
            txtStudentKnum.Name = "txtStudentKnum";
            txtStudentKnum.PlaceholderText = "K00999999...";
            txtStudentKnum.Size = new Size(188, 31);
            txtStudentKnum.TabIndex = 8;
            // 
            // lblStudentKnum
            // 
            lblStudentKnum.AutoSize = true;
            lblStudentKnum.Location = new Point(36, 36);
            lblStudentKnum.Margin = new Padding(4, 0, 4, 0);
            lblStudentKnum.Name = "lblStudentKnum";
            lblStudentKnum.Size = new Size(91, 25);
            lblStudentKnum.TabIndex = 7;
            lblStudentKnum.Text = "KNumber:";
            // 
            // lblCounty
            // 
            lblCounty.AutoSize = true;
            lblCounty.Location = new Point(36, 246);
            lblCounty.Margin = new Padding(4, 0, 4, 0);
            lblCounty.Name = "lblCounty";
            lblCounty.Size = new Size(73, 25);
            lblCounty.TabIndex = 9;
            lblCounty.Text = "County:";
            // 
            // txtPresent
            // 
            txtPresent.Location = new Point(178, 284);
            txtPresent.Margin = new Padding(4);
            txtPresent.Name = "txtPresent";
            txtPresent.PlaceholderText = "True/False";
            txtPresent.Size = new Size(188, 31);
            txtPresent.TabIndex = 11;
            // 
            // lblPresent
            // 
            lblPresent.AutoSize = true;
            lblPresent.Location = new Point(36, 288);
            lblPresent.Margin = new Padding(4, 0, 4, 0);
            lblPresent.Name = "lblPresent";
            lblPresent.Size = new Size(74, 25);
            lblPresent.TabIndex = 10;
            lblPresent.Text = "Present:";
            // 
            // txtPhoneNum
            // 
            txtPhoneNum.Location = new Point(178, 326);
            txtPhoneNum.Margin = new Padding(4);
            txtPhoneNum.Name = "txtPhoneNum";
            txtPhoneNum.PlaceholderText = "0831234567...";
            txtPhoneNum.Size = new Size(188, 31);
            txtPhoneNum.TabIndex = 13;
            // 
            // lblPhoneNumber
            // 
            lblPhoneNumber.AutoSize = true;
            lblPhoneNumber.Location = new Point(35, 330);
            lblPhoneNumber.Margin = new Padding(4, 0, 4, 0);
            lblPhoneNumber.Name = "lblPhoneNumber";
            lblPhoneNumber.Size = new Size(136, 25);
            lblPhoneNumber.TabIndex = 12;
            lblPhoneNumber.Text = "Phone Number:";
            // 
            // cbxStudentYear
            // 
            cbxStudentYear.FormattingEnabled = true;
            cbxStudentYear.Items.AddRange(new object[] { "1", "2", "3", "4" });
            cbxStudentYear.Location = new Point(176, 200);
            cbxStudentYear.Margin = new Padding(4);
            cbxStudentYear.Name = "cbxStudentYear";
            cbxStudentYear.Size = new Size(188, 33);
            cbxStudentYear.TabIndex = 14;
            // 
            // cbxCounty
            // 
            cbxCounty.FormattingEnabled = true;
            cbxCounty.Items.AddRange(new object[] { "Carlow", "Cavan", "Clare", "Cork", "Donegal", "Dublin", "Galway", "Kerry", "Kildare", "Kilkenny", "Laois", "Leitrim", "Limerick", "Longford", "Louth", "Mayo", "Meath", "Monaghan", "Offaly", "Roscommon", "Sligo", "Tipperary", "Waterford", "Westmeath", "Wexford", "Wicklow" });
            cbxCounty.Location = new Point(178, 242);
            cbxCounty.Margin = new Padding(4);
            cbxCounty.Name = "cbxCounty";
            cbxCounty.Size = new Size(188, 33);
            cbxCounty.TabIndex = 15;
            // 
            // btnAddStudent
            // 
            btnAddStudent.Location = new Point(56, 420);
            btnAddStudent.Margin = new Padding(4);
            btnAddStudent.Name = "btnAddStudent";
            btnAddStudent.Size = new Size(118, 46);
            btnAddStudent.TabIndex = 16;
            btnAddStudent.Text = "&Accept";
            btnAddStudent.UseVisualStyleBackColor = true;
            btnAddStudent.Click += btnAddStudent_Click;
            // 
            // btnStudentCancel
            // 
            btnStudentCancel.Location = new Point(236, 420);
            btnStudentCancel.Margin = new Padding(4);
            btnStudentCancel.Name = "btnStudentCancel";
            btnStudentCancel.Size = new Size(118, 46);
            btnStudentCancel.TabIndex = 17;
            btnStudentCancel.Text = "&Cancel";
            btnStudentCancel.UseVisualStyleBackColor = true;
            btnStudentCancel.Click += btnStudentCancel_Click;
            // 
            // txtPresentMark
            // 
            txtPresentMark.Location = new Point(176, 372);
            txtPresentMark.Margin = new Padding(4);
            txtPresentMark.Name = "txtPresentMark";
            txtPresentMark.PlaceholderText = "5..";
            txtPresentMark.Size = new Size(188, 31);
            txtPresentMark.TabIndex = 19;
            // 
            // lblPresentMarks
            // 
            lblPresentMarks.AutoSize = true;
            lblPresentMarks.Location = new Point(36, 372);
            lblPresentMarks.Margin = new Padding(4, 0, 4, 0);
            lblPresentMarks.Name = "lblPresentMarks";
            lblPresentMarks.Size = new Size(127, 25);
            lblPresentMarks.TabIndex = 18;
            lblPresentMarks.Text = "Present Marks:";
            // 
            // StudentForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(418, 489);
            Controls.Add(txtPresentMark);
            Controls.Add(lblPresentMarks);
            Controls.Add(btnStudentCancel);
            Controls.Add(btnAddStudent);
            Controls.Add(cbxCounty);
            Controls.Add(cbxStudentYear);
            Controls.Add(txtPhoneNum);
            Controls.Add(lblPhoneNumber);
            Controls.Add(txtPresent);
            Controls.Add(lblPresent);
            Controls.Add(lblCounty);
            Controls.Add(txtStudentKnum);
            Controls.Add(lblStudentKnum);
            Controls.Add(lblStudentYear);
            Controls.Add(txtGender);
            Controls.Add(lblGender);
            Controls.Add(txtStudentAge);
            Controls.Add(lblAge);
            Controls.Add(txtStudentName);
            Controls.Add(lblStudentName);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "StudentForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Study Group | Add Student";
            Load += StudentForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblStudentName;
        private TextBox txtStudentName;
        private TextBox txtStudentAge;
        private Label lblAge;
        private TextBox txtGender;
        private Label lblGender;
        private Label lblStudentYear;
        private TextBox txtStudentKnum;
        private Label lblStudentKnum;
        private Label lblCounty;
        private TextBox txtPresent;
        private Label lblPresent;
        private TextBox txtPhoneNum;
        private Label lblPhoneNumber;
        private ComboBox cbxStudentYear;
        private ComboBox cbxCounty;
        private Button btnAddStudent;
        private Button btnStudentCancel;
        private TextBox txtPresentMark;
        private Label lblPresentMarks;
    }
}
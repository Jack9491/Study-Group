﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace GroupProject
{

    public partial class StudentForm : Form
    {
        public bool AddStudent { get; set; }

        public Student student { get; set; }

        public StudentForm()
        {
            InitializeComponent();
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {

            if (AddStudent)
            {
                this.student = new Student();
            }
            this.LoadStudentData();

            this.DialogResult = DialogResult.OK;

        }

        private void DisplayStudent()
        {

            txtStudentName.Text = student.StudentName;
            txtStudentAge.Text = student.StudentAge.ToString();
            txtGender.Text = student.Gender;
            cbxStudentYear.Text = student.StudyYear.ToString();
            txtStudentKnum.Text = student.KNum;
            cbxCounty.Text = student.County;
            txtPresent.Text = student.IsPresent.ToString();
            txtPhoneNum.Text = student.StudentPhoneNumber;
            txtPresentMark.Text = student.ParticipationScore.ToString();


        }

        private void LoadStudentData()
        {
            student.StudentName = txtStudentName.Text;
            student.StudentAge = Convert.ToInt32(txtStudentAge.Text);
            student.Gender = txtGender.Text;
            student.StudyYear = Convert.ToInt32(cbxStudentYear.Text);
            student.KNum = txtStudentKnum.Text;
            student.County = cbxCounty.Text;
            student.IsPresent = bool.Parse(txtPresent.Text);
            student.StudentPhoneNumber = txtPhoneNum.Text;
            student.ParticipationScore = Convert.ToInt32(txtPresentMark.Text);
        }


        private void StudentForm_Load(object sender, EventArgs e)
        {
            if (AddStudent)
            {
                this.Text = "Add Student";
                txtStudentName.ReadOnly = false;  // allow entry of new student name
            }
            else
            {
                this.Text = "Modify Student";
                txtStudentName.ReadOnly = true;   // can't change existing student name
                this.DisplayStudent();
            }
        }

        private void btnStudentCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtStudentName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
